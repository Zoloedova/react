import React from "react";
import "../css/Header.css";

import Logo from "./Logo";
import Menu from "./menu/Menu";

function Header() {
  return (
    <header>
      <div className="container">
        <div className="row justify-content-between">
          <div className="col-1">
            <Logo />
          </div>
          <nav className="row col-9">
            <Menu />
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;
