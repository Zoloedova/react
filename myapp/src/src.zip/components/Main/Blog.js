import React from "react";

import "../../css/Main/Blog.css";

function Blog() {
  return (
		<section id="blog" className="Blog">
		
		</section>
	);
}

export default Blog;
