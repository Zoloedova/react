import React from "react";

import "../../css/Main/About.css";

function About() {
  return (
		<section id="about" className="About">
			
		</section>
	);
}

export default About;
