import React from "react";

import "../../css/Main/Contacts.css";

function Contacts() {
  return (
		<section id="contacts" className="Contacts">

		</section>
	);
}

export default Contacts;
