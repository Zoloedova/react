import React from "react";

import "../../css/Main/Catalog.css";

function Catalog() {
  return (
		<section id="catalog" className="Catalog">
		
		</section>
	);
}

export default Catalog;
