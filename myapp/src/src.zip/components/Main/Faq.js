import React from "react";

import "../../css/Main/Faq.css";

function Faq() {
  return (
		<section id="faq" className="Faq">

		</section>
	);
}

export default Faq;
