import React from "react";

import "../css/ArrowTop.css";

function ArrowTop() {
  return (
    <button className="ArrowTop"></button>
  );
}

export default ArrowTop;
