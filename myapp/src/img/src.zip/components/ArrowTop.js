import React from "react";

import "../css/ArrowTop.css";

function ArrowTop() {
  return (
    <button className="ArrowTop animate__animated hidden"></button>
  );
}

export default ArrowTop;
