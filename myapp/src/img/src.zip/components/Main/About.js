import React from "react";

import "../../css/Main/About.css";

function About() {
  return (
    <section id="about" className="About">
      <div className="container">
        <div className="row">
          <h2 className="col-12 section-title">О нас</h2>
        </div>
      </div>
    </section>
  );
}

export default About;
